#!/usr/bin/env bash
# Verifier entrypoint. Runs in the same environment image as the agent
# (task/environment/Dockerfile), with /tests overlaid at verify time.
# All test dependencies (pytest, pytest-json-ctrf) are baked into the
# environment image already - this script installs nothing.
set -uo pipefail

mkdir -p /logs/verifier

pytest /tests/test_outputs.py \
    --ctrf /logs/verifier/ctrf-report.json \
    -v

if [ $? -eq 0 ]; then
    echo 1 > /logs/verifier/reward.txt
else
    echo 0 > /logs/verifier/reward.txt
fi

exit 0
