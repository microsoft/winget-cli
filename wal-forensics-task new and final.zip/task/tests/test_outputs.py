"""
Verifier for the WAL Forensics task.

Checks the agent's recovered final state at /app/output/final_state.json
against the pre-computed ground truth in /tests/expected_state.json
(overlaid into the container at verify time, never visible to the agent
during the solve phase).

Ground truth was computed independently of the agent's parser: it is
the replay, in true sequence-number order, of every write that
survived the seeded corruption (i.e. every op except the one destroyed
by the torn-tail truncation and the one destroyed by the bit flip -
those two writes never durably completed / are provably corrupted, so
no correct recovery tool can or should reproduce them).
"""
import hashlib
import json
import os

OUTPUT_PATH = "/app/output/final_state.json"
EXPECTED_PATH = os.path.join(os.path.dirname(__file__), "expected_state.json")


def _canonical_hash(data):
    canonical = json.dumps(data, sort_keys=True, separators=(",", ":"))
    return hashlib.sha256(canonical.encode("utf-8")).hexdigest()


def _load_expected():
    with open(EXPECTED_PATH, "r") as f:
        # expected_state.json is already stored pre-canonicalized
        return json.loads(f.read())


def test_output_file_exists():
    """The agent must produce /app/output/final_state.json."""
    assert os.path.exists(OUTPUT_PATH), (
        f"Expected output file not found at {OUTPUT_PATH}"
    )


def test_output_is_valid_json_array_of_key_value_objects():
    """Output must be a JSON array of {"key": str, "value": str} objects."""
    with open(OUTPUT_PATH, "r") as f:
        data = json.load(f)
    assert isinstance(data, list), "Top-level JSON must be an array"
    for entry in data:
        assert isinstance(entry, dict), "Each entry must be a JSON object"
        assert set(entry.keys()) == {"key", "value"}, (
            f"Each entry must have exactly 'key' and 'value' fields, got {sorted(entry.keys())}"
        )
        assert isinstance(entry["key"], str)
        assert isinstance(entry["value"], str)


def test_output_sorted_by_key_with_no_duplicates():
    """Entries must be sorted ascending by key with no duplicate keys."""
    with open(OUTPUT_PATH, "r") as f:
        data = json.load(f)
    keys = [entry["key"] for entry in data]
    assert keys == sorted(keys), "Entries must be sorted ascending by key"
    assert len(keys) == len(set(keys)), "Duplicate keys found in output"


def test_final_state_exact_match():
    """
    The recovered final state must exactly match ground truth.

    This is a discrete-state recovery problem (there is exactly one
    correct answer given the corrupted log), so no partial credit is
    given: every corruption instance - the torn tail, the bit flip,
    and the cross-writer interleaving - must be resolved correctly for
    this to pass.
    """
    with open(OUTPUT_PATH, "r") as f:
        agent_data = json.load(f)

    expected_data = _load_expected()

    agent_hash = _canonical_hash(agent_data)
    expected_hash = _canonical_hash(expected_data)

    assert agent_hash == expected_hash, (
        "Recovered final state does not match ground truth. "
        f"Got {len(agent_data)} keys, expected {len(expected_data)} keys."
    )
