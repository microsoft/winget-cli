# WAL Forensics: Recover the True Final State from a Corrupted Log

A storage engine crashed. Its write-ahead log survived on disk, but it
is damaged: `/app/data/wal.log` is a binary write-ahead log (WAL) that
was written concurrently, unsynchronized, by two writer threads, and
was then hit by a crash and a media error. Your job is to recover the
correct final key/value state that a properly functioning recovery
process would produce from this exact file.

## WAL binary format

The file is a back-to-back sequence of variable-length records. All
integers are big-endian (network byte order). Each record is laid out
as:

```
[seq: u64][writer_id: u8][op: u8][keylen: u32][key: keylen bytes]
[vallen: u32][value: vallen bytes][crc32: u32]
```

- `seq`: a globally unique, monotonically increasing sequence number.
  It was issued from a single shared counter at the moment each
  operation was created, *before* that operation's writer physically
  wrote its record to the file.
- `writer_id`: 1 or 2, identifying which of the two writer threads
  produced the record.
- `op`: `0` = PUT (insert/overwrite `key` with `value`), `1` = DELETE
  (tombstone `key`; `vallen` is always `0` and there are no value
  bytes for a DELETE record).
- `keylen` / `key`: the key, UTF-8 encoded.
- `vallen` / `value`: the value, UTF-8 encoded (empty for DELETE).
- `crc32`: a CRC-32 checksum computed over every preceding byte of
  that same record (the `seq` field through the `value` field,
  inclusive). A record is only trustworthy if this checksum matches.

## What's wrong with the file

Because the two writer threads were unsynchronized, **the physical
byte order of records in the file is not reliable evidence of write
order** — records from the two writers can appear interleaved in an
order that does not match their `seq` values. Only the `seq` field
tells you the true logical order.

The file also contains damage from the crash:

- Somewhere in the file, a record's bytes have been altered in a way
  that fails its own `crc32` check, while everything around it is
  intact and well-formed.
- The very end of the file was cut off mid-write of what would have
  been the last physical record — the crash happened while that
  record's `write()` call was still in progress.

A record that fails validation could be broken for either of these two
different reasons, and they call for different handling: a checksum
failure inside an otherwise complete, well-formed record means only
*that* record's data was lost (skip it and keep going); insufficient
remaining bytes to even contain a complete, well-formed record means
you've hit the crash boundary itself (nothing after that point in the
file is trustworthy). Any data that is genuinely unrecoverable this
way should simply be treated as lost — do not attempt to guess or
reconstruct it.

## What to produce

Write the recovered final state to `/app/output/final_state.json` as
a JSON array of objects, each with exactly two string fields, `"key"`
and `"value"`. Include only keys that are live (not tombstoned) in the
final, correctly-reconciled state. Sort the array ascending by `key`,
with no duplicate keys. Example shape:

```json
[
  {"key": "key01", "value": "v39-55882"},
  {"key": "key02", "value": "v49-55952"}
]
```

There is exactly one correct final state for this file — build your
recovery logic to be correct in general, not tuned to guess the
answer.

You have 1800 seconds to complete this task.
