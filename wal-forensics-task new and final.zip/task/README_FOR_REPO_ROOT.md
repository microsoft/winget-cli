# WAL Forensics — Recovering a Corrupted Storage-Engine Log

**Category:** Systems & Infrastructure
**Sub-category:** Data Recovery / Storage Engine Internals

## Overview

The agent is given a corrupted write-ahead log (WAL) written by two
concurrent, unsynchronized writer threads in a small key-value storage
engine. It must recover the true final key-value state despite three
realistic crash-time corruption mechanisms: a torn tail write, an
isolated bit-flip inside an otherwise complete record, and physical
byte-interleaving that does not match logical write order.

## Approach

Each record is CRC-32 checked and carries a globally monotonic `seq`
field assigned before the physical write happens. Physical file position
is not a reliable ordering signal because the two writers are
unsynchronized; only `seq` order and per-record CRC validity are
trustworthy. Records that fail CRC are handled differently depending on
*why* they failed: a record with too few remaining bytes to hold its
declared length is a torn tail (crash boundary — stop parsing), while a
full-length record with a mismatched CRC is an isolated bit-flip (drop
just that record and resync forward for the next valid one). Every
CRC-valid record is then sorted by `seq` and replayed in that order to
build the final state.

## Environment

Single Python container. `environment/data/wal.log` is a pre-generated,
seeded corrupted WAL (~2.5KB, 70 logical operations across two writers,
16 keys). The generation/corruption process and its seed search (to
guarantee all three corruption mechanisms are present, plus at least one
genuine cross-writer seq inversion) live outside the shipped task and are
not part of what's committed — only the resulting artifact is.

## Verification

`tests/expected_state.json` holds the ground-truth final state, computed
directly from the known pre-corruption op sequence (independent of any
parsing/recovery implementation). The verifier requires an exact match
against the agent's `/app/output/final_state.json` — no tolerance band,
since this is a discrete-state reconstruction problem with exactly one
correct answer. Additional checks confirm the output file exists, is
valid JSON in the documented schema, and has no duplicate keys.
