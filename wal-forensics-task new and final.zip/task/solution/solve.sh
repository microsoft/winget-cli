#!/usr/bin/env bash
# Reference (oracle) solution entrypoint. Harbor mounts this directory at
# /solution and runs solve.sh inside the task's environment container.
set -euo pipefail

mkdir -p /app/output
python3 /solution/solve.py /app/data/wal.log /app/output/final_state.json
