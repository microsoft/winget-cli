#!/usr/bin/env python3
"""
Reference solution for the WAL Forensics task.

Parses a corrupted write-ahead log, recovers every record that is
provably intact (valid CRC), reconciles physical write order against
the embedded global sequence number, and emits the final key/value
state.
"""
import json
import os
import struct
import sys
import zlib

HEADER_FMT = ">QBBII"
HEADER_LEN = struct.calcsize(HEADER_FMT)  # 18
CRC_LEN = 4
OP_PUT = 0
OP_DELETE = 1

RESYNC_BOUND = 8192  # sanity bound so a corrupted length field can't cause a false resync


def try_parse_at(data, offset):
    """Attempt to parse+validate one record starting at `offset`.
    Returns (record_dict, next_offset) on success, or None on failure.
    Never raises - all failures are reported as None so callers can
    treat "doesn't parse here" and "parses but bad" uniformly during
    resync scanning."""
    if offset < 0 or offset + HEADER_LEN > len(data):
        return None
    try:
        seq, writer_id, op, keylen, vallen = struct.unpack(
            HEADER_FMT, data[offset:offset + HEADER_LEN]
        )
    except struct.error:
        return None

    if op not in (OP_PUT, OP_DELETE):
        return None
    if op == OP_DELETE and vallen != 0:
        return None
    # sanity bound on absurd declared lengths (guards against a flipped
    # length field producing a huge bogus record during resync scanning)
    if keylen > RESYNC_BOUND or vallen > RESYNC_BOUND:
        return None

    total_len = HEADER_LEN + keylen + vallen + CRC_LEN
    if offset + total_len > len(data):
        return None  # not enough bytes for the declared record -> caller decides torn-tail vs resync-fail

    body = data[offset:offset + HEADER_LEN + keylen + vallen]
    stored_crc = struct.unpack(">I", data[offset + HEADER_LEN + keylen + vallen: offset + total_len])[0]
    if (zlib.crc32(body) & 0xFFFFFFFF) != stored_crc:
        return None

    key = data[offset + HEADER_LEN: offset + HEADER_LEN + keylen].decode("utf-8", errors="strict")
    value = data[offset + HEADER_LEN + keylen: offset + HEADER_LEN + keylen + vallen].decode(
        "utf-8", errors="strict"
    )
    record = {"seq": seq, "writer": writer_id, "op": op, "key": key, "value": value}
    return record, offset + total_len


def parse_wal(data):
    records = []
    pos = 0
    n = len(data)

    while pos < n:
        # Not even enough bytes left to read a header -> torn tail, stop.
        if pos + HEADER_LEN > n:
            break

        parsed = try_parse_at(data, pos)
        if parsed is not None:
            record, next_pos = parsed
            records.append(record)
            pos = next_pos
            continue

        # Parsing/validation failed at `pos`. Disambiguate:
        # can we even read a header + declared lengths here?
        try:
            _seq, _wid, _op, keylen, vallen = struct.unpack(
                HEADER_FMT, data[pos:pos + HEADER_LEN]
            )
            declared_total = HEADER_LEN + keylen + vallen + CRC_LEN
        except struct.error:
            declared_total = None

        if declared_total is None or pos + declared_total > n:
            # Header (or its declared body) doesn't fit in the
            # remaining bytes at all -> this is the crash boundary
            # (torn tail). Stop parsing entirely; nothing after this
            # point is trustworthy.
            break

        # Enough bytes existed for a complete record at `pos`, but it
        # failed CRC -> an isolated bit-flip inside an otherwise
        # complete record, not a torn tail. Discard just this record
        # and resync by scanning forward for the next offset at which
        # a record both parses and validates.
        resync_limit = min(n, pos + 1 + RESYNC_BOUND)
        found = False
        for cand in range(pos + 1, resync_limit):
            attempt = try_parse_at(data, cand)
            if attempt is not None:
                record, next_pos = attempt
                records.append(record)
                pos = next_pos
                found = True
                break
        if not found:
            # No valid record found within the bound; nothing further
            # in the file can be trusted.
            break

    return records


def reconcile(records):
    """Sort by the global sequence number (not physical file position),
    and defensively drop any record whose seq regresses relative to
    the max seq already applied - this can only happen if a corrupted
    record coincidentally passed its CRC check."""
    ordered = sorted(records, key=lambda r: r["seq"])
    state = {}
    max_seq_applied = -1
    for r in ordered:
        if r["seq"] < max_seq_applied:
            continue
        max_seq_applied = r["seq"]
        if r["op"] == OP_PUT:
            state[r["key"]] = r["value"]
        else:
            state.pop(r["key"], None)
    return state


def main():
    wal_path = sys.argv[1] if len(sys.argv) > 1 else "/app/data/wal.log"
    out_path = sys.argv[2] if len(sys.argv) > 2 else "/app/output/final_state.json"

    with open(wal_path, "rb") as f:
        data = f.read()

    records = parse_wal(data)
    state = reconcile(records)
    final_list = [{"key": k, "value": v} for k, v in sorted(state.items())]

    os.makedirs(os.path.dirname(out_path), exist_ok=True)
    with open(out_path, "w") as f:
        json.dump(final_list, f, indent=2)
        f.write("\n")


if __name__ == "__main__":
    main()
